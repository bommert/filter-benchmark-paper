set.seed(123)
options(mlr.debug.seed = 123L)
configureMlr(show.info = FALSE, show.learner.output = FALSE)

library(checkmate)
library(BBmisc)

